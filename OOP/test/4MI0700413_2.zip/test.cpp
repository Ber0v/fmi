#include <iostream>
#include "Dish.h"
#include "Menu.h"

int main()
{
	Menu Master_Chef(500);
	Dish tarator("Tarator", "krastavica", 50);
	Dish patatnik("patatnik", "kartofi", 60);
	Dish pizza("pizza", "peperoni", 200);
	Dish princesa("princesa", "kaima", 100);

	Master_Chef += tarator;
	Master_Chef += patatnik;
	Master_Chef += pizza;
	Master_Chef += princesa;

}