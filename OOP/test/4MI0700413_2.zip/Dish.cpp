#include "Dish.h"
#include <iostream>
#include <cstring>
#include "Menu.h"

Dish::Dish()
	:name(nullptr), recept(nullptr), kalories(0)
{
	setName("NoName");
	setRecept("NoRecept");
}

Dish::Dish(const char* name, const char* recept, unsigned kalories)
{
	try
	{
		setName(name);
		setRecept(recept);
		setKalories(kalories);
	}
	catch (...)
	{
		free();
	}
}

Dish::Dish(const Dish& other)
{
	Dish(other.name, other.recept, other.kalories);
}

Dish& Dish::operator=(const Dish& other)
{
}

Dish::~Dish()
{
	free();
}

bool Dish::operator==(const Dish& other) const
{
	return (strcmp(name, other.name) == 0 && strcmp(recept, other.recept) && kalories == other.kalories);
}

bool Dish::operator!=(const Dish& other) const
{
	return !(*this == other);
}

void Dish::setName(const char* name)
{
	if (!name) throw std::exception("");

	int len = strlen(name);
	char* temp = new char[len + 1];
	strcpy(temp, name);

	delete[] name;
	this->name = temp;
}

void Dish::setRecept(const char* recept)
{
	if (!recept) throw std::exception("");

	int len = strlen(recept);
	char* temp = new char[len + 1];
	strcpy(temp, recept);

	delete[] recept;
	this->recept = temp;
}

void Dish::setKalories(unsigned kalories)
{
	this->kalories = kalories;
}

void Dish::free()
{
	delete[] name;
	delete[] recept;
	kalories = 0;
	name = nullptr;
	recept = nullptr;
}
