#include "Menu.h"
#include "Dish.h"
#include <cstring>

Menu::Menu(unsigned maxKalories)
	:maxKalories(maxKalories)
{
	if (maxKalories < 100) throw;
}

bool Menu::operator+=(const Dish dish)
{
	if (allKalories + dish.getKalories() <= maxKalories)
	{
		Dish(dish);
		return true;
	}
	return false;
}

bool Menu::operator-=(const Dish& dish)
{
	for (unsigned i = 0; i < 100; i++)
	{
		if (this->dish[i] == dish)
		{

		}
	}
}

int Menu::operator[](const char* recept)
{
	int index = 0;
	for (size_t i = 0; i < 100; i++)
	{
		if (strcmp(dish[i].getRecept(), recept) == 0)
		{
			if (dish[i].getKalories() < dish[index].getKalories()) index = i;
		}
	}
	return index;
}

const int Menu::operator[](const char* recept) const
{
	int index = 0;
	for (size_t i = 0; i < 100; i++)
	{
		if (strcmp(dish[i].getRecept(), recept) == 0)
		{
			if (dish[i].getKalories() < dish[index].getKalories()) index = i;
		}
	}
	return index;
}
