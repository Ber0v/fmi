#pragma once
#include "Dish.h"
class Dish;
class Menu
{
	friend class Dish;
public:
	Menu(unsigned maxKalories);
	bool operator+=(const Dish dish);
	bool operator-=(const Dish& dish);
	int operator[](const char* recept);
	const int operator[](const char* recept)const;

	unsigned getAllKalories() const {return allKalories;};

private:
	Dish dish[100];
	const unsigned maxKalories;
	unsigned allKalories;
};