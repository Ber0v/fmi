#pragma once
class Dish
{
public:
	Dish();
	Dish(const char* name, const char* recept, unsigned kalories);
	Dish(const Dish& other);
	Dish& operator=(const Dish& other);
	~Dish();

	bool operator==(const Dish& other)const;
	bool operator!=(const Dish& other)const;

	//getters
	const char* getName() const { return this->name; };
	const char* getRecept() const { return this->recept; };
	unsigned getKalories() const { return this->kalories; };

	//setters
	void setName(const char* name);
	void setRecept(const char* recept);
	void setKalories(unsigned kalories);


private:
	void free();
private:
	char* name;
	char* recept;
	unsigned kalories;
};